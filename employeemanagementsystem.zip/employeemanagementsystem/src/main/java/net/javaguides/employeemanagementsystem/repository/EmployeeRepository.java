package net.javaguides.employeemanagementsystem.repository;

import net.javaguides.employeemanagementsystem.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // All the CRUD Database Methods.

}
