import './App.css';
import AddEmployeeComponent from './components/AddEmployeeComponent';
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import HeaderComponent from './components/HeaderComponent';
import ListEmployeeComponent from './components/ListEmployeeComponent';
import FooterComponent from './components/FooterComponent';

function App() {
  return (
    <div>

      <HeaderComponent/>
      <div className = "container">
        <BrowserRouter>
        <Routes>
          <Route path = "/" element = {<ListEmployeeComponent/>}/>
          <Route path = "/add-employee" element = {<AddEmployeeComponent/>}/>
          <Route path = "/edit-employee/:id" element = {<AddEmployeeComponent/>}/>
          <Route path = "/employees" element = {<ListEmployeeComponent/>}/>
        </Routes>
        </BrowserRouter>
      </div>
      <FooterComponent/>
      
    </div>
  );
}

export default App;
