import React from 'react'

const HeaderComponent = () => {
  return (
    <div>
      <header>
        <nav className = "navbar bg-dark navbar-dark navbar-expand-md">
            <div>
                <a href = "https://javaguides.net" className = "navebar-brand">Employee Management Application</a>
            </div>
        </nav>
      </header>
    </div>
  )
}

export default HeaderComponent
